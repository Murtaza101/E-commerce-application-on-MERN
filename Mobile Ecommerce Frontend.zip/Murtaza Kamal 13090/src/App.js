import React, { Component } from 'react';
import { Switch, Route } from 'react-router-dom';
import logo from './logo.PNG';
// CSS

import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import './css/flaticon.css';
import './css/responsive.css';
import './css/style.css';
import './css/themify-icons.css';

import NavigationBar from './components/Navbar';
import Details from './components/Details';
import Cart from './components/Cart/Cart';
import Product from './components/Product';
import ProductList from './components/ProductList';
import Default from './components/Default';
import Header from './components/Header';
import Tracking from './components/Tracking'
import Contact from './components/Contact';
import Banner from './components/Banner';
import LandingPage from './components/LandingPage';
import Modal from './components/Modal';
import Login from './components/Login';
import SignUp from './components/SignUp';

export default class App extends Component {
  render() {
    return ( 
      <React.Fragment>     
        <Switch>
          <Route path='/create' component={Cart} />
          <Route path='/user' component={SignUp} />


          <Route path='/phones' component={ProductList} />
          <Route path='/tracking' component={Tracking} />
          <Route path='/contact' component={Contact} />
          <Route path='/details' component={Details} />
          <Route path='/login' component={Login} />
          <Route path='/signup' component={SignUp} />
          <Route path='/cart' component={Cart} />
          <Route exact path='/' component={LandingPage} />
          <Route component={Default} />
        </Switch>
        <Modal />
      </React.Fragment>
    );
  }
}


