import React, { Component } from 'react';
import styled from 'styled-components';
import { Link } from 'react-router-dom';
import { ButtonContainer } from './Button';

export default class Banner extends Component {
    render() {
        return (
            <section className="home_banner_area mb-40">
                <div className="banner_inner d-flex align-items-center">
                    <div className="container">
                        <div className="banner_content row">
                            <div className="col-lg-12">
                                <p className="sub text-uppercase">Enter the Digital World</p>
                                <h3> <span> With </span> ELECTROP </h3>
                                <Link to="/phones">
                                    <ButtonContainer>View Products</ButtonContainer>
                                </Link>
                            </div>
                        </div>
                    </div>
                </div>
        </section>
        )
    }
}
