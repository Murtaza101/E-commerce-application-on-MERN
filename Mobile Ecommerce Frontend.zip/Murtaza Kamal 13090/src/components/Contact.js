import React, { Component } from 'react'

export default class Contact extends Component {
    render() {
        return (
            <div>
                <h1>hello from contacts</h1>
            </div>
        )
    }
}
