import React, { Component } from 'react';
import glitch from '../img/glitch.jpg';
import NavigationBar from './Navbar';
import styled from 'styled-components';

export default class Default extends Component {
    render() {
        console.log(this.props);
        return (
            <React.Fragment>
                <BG src={glitch} className="img-fluid rounded mx-auto d-block" alt="Responsive image" />
            </React.Fragment>
        );
    }
}

const BG = styled.img`
    width: 100%;
    height: 100rem;
`;