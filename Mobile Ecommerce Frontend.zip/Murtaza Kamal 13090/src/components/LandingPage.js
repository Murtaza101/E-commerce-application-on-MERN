import React, { Component } from 'react';
import Header from './Header';
import NavigationBar from './Navbar';
import Banner from './Banner';
import ProductList from './ProductList';

export default class LandingPage extends Component {
    render() {
        return (
            <React.Fragment>
                <Header />
                <NavigationBar />
                <Banner />
            </React.Fragment>
        )
    }
}
