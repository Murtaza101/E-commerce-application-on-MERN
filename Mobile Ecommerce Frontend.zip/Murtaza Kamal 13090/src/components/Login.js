import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import NavigationBar from './Navbar';
import Header from './Header';
import styled from 'styled-components';

export default class Login extends Component {
    render() {
        return (
            <React.Fragment>
                <Header />
                <NavigationBar />
                <div className="login-form">
                    <form action="/examples/actions/confirmation.php" method="post">
                        <h2 className="text-center">Log in</h2>       
                        <div className="form-group">
                            <input type="text" className="form-control" placeholder="Username" required="required" />
                        </div>
                        <div className="form-group">
                            <input type="password" className="form-control" placeholder="Password" required="required" />
                        </div>
                        <div className="form-group">
                            <LoginButton type="submit" className="btn btn-primary btn-block">Log in</LoginButton>
                        </div>        
                    </form>
                    <p className="text-center"><Atag href="/signup">Create an Account</Atag></p>
                </div>
            </React.Fragment>
        );
    }
}

const LoginButton = styled.button`
    background-color: var(--mainBlue) !important;
    border-color: var(--mainBlue) !important;
`;

const Atag = styled.a`
    color: var(--mainBlue) !important;
`;
