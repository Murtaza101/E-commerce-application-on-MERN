import React, { Component } from 'react';
import axios from 'axios'
import NavigationBar from './Navbar';
import Header from './Header';

let axiosConfig = {
    headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        "Access-Control-Allow-Origin": "*",
    }
};

export default class SignUp extends Component {

    constructor(props) {
        super(props);

        this.handleChange = this.handleChange.bind(this);
        this.handleEmail = this.handleEmail.bind(this);
        this.handlePassword = this.handlePassword.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    
        this.state = {
            username: '',
            email: '',
            password: '',
        };
    }

    componentDidMount() {
        this.setState({
            username: ''
        });
    };

    handleChange = event => {
        this.setState({ username: event.target.value});
    };

    handleEmail = event => {
        this.setState({ email: event.target.value});
    };

    handlePassword = event => {
        this.setState({ password: event.target.value});
    };

    handleSubmit = event => {
        event.preventDefault();

        const user = {
            username: this.state.username,
            email: this.state.email,
            password: this.state.password,
        };

        axios.post(`http://localhost:5000/users/register`, user)
        .then(res => {
            console.log(res);
            console.log(res.data);
        })
    };

    render() {
        return (
            <React.Fragment>
            <Header />    
            <NavigationBar />
            <div className="signup-form">	

            <form method="post" onSubmit={ this.handleSubmit }>

                <h2>Create Account</h2>
                <p className="lead">It's free and hardly takes more than 30 seconds.</p>
                <div className="form-group">
                    <div className="input-group">
                        <span className="input-group-addon"><i className="fa fa-user"></i></span>
                        <input type="text" className="form-control" name="username" placeholder="Username" required="required" value={ this.state.username } onChange={ this.handleChange } />
                    </div>
                </div>
                <div className="form-group">
                    <div className="input-group">
                        <span className="input-group-addon"><i className="fa fa-paper-plane"></i></span>
                        <input type="email" className="form-control" name="email" placeholder="Email Address" required="required" value={ this.state.email } onChange={ this.handleEmail } />
                    </div>
                </div>
                <div className="form-group">
                    <div className="input-group">
                        <span className="input-group-addon"><i className="fa fa-lock"></i></span>
                        <input type="text" className="form-control" name="password" placeholder="Password" required="required" value={ this.state.password } onChange={ this.handlePassword } />
                    </div>
                </div>
                <div className="form-group">
                    <div className="input-group">
                        <span className="input-group-addon">
                            <i className="fa fa-lock"></i>
                            <i className="fa fa-check"></i>
                        </span>
                        <input type="text" className="form-control" name="confirm_password" placeholder="Confirm Password" required="required" />
                    </div>
                </div>        
                <div className="form-group">
                    <button type="submit" className="btn btn-primary btn-block btn-lg">Sign Up</button>
                </div>
                <p className="small text-center">By clicking the Sign Up button, you agree to our <br /><a href="#">Terms &amp; Conditions</a>, and <a href="#">Privacy Policy</a>.</p>
            </form>
            <div className="text-center">Already have an account? <a href="/login">Login here</a>.</div>
        </div>
        </React.Fragment>
        );
    }
}
