import React, { Component } from 'react'

export default class Tracking extends Component {
    render() {
        return (
            <div>
                <h1>Hello from tracking</h1>
            </div>
        )
    }
}
